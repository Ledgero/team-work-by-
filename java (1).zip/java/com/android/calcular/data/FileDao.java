package com.android.calcular.data;

import android.content.Context;
import android.print.PrintManager;
import android.util.Log;

import com.android.calcular.MainActivity;
import com.android.calcular.adapter.MyPrintPdfAdapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * project name: Calcular
 * Date 2021/10/23 15:34
 *
 * @PackageName: com.android.calcular.data
 * @ClassName: FileDao
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class FileDao {
    public static String folderPath;
    /**
    *@Params: [file]
    *@Return: java.lang.String
    *@Author: Likailing
    *@Date: 2021/10/24 13:47
    *@Desciption:
    */
    public String getText(String name){
        File file=new File(folderPath+File.separator+name+".txt");
        Log.d("File",file.getName());
        StringBuilder content = null;
        BufferedReader buffRea = null;

        if(!file.exists()){
            System.out.println("文件不存在");
            return "";
        }
        else{
            try{
                content=new StringBuilder();
                buffRea=new BufferedReader(new FileReader(file));
                String str ;
                while((str=buffRea.readLine())!=null){
                    content.append(str+"\n");
                }
                buffRea.close();
            }
            catch(IOException ex){
                System.out.println("获取文件错误");
                ex.printStackTrace();
            }
            finally{

            }
        }
        System.out.println("获取文件内容"+content.toString());
        return content.toString();
    }

    public boolean printFile(String name,String info){
        String gradePath=folderPath+ File.separator+name+".txt";
        try {
            FileOutputStream grdStream=new FileOutputStream(gradePath);
            BufferedWriter grdWriter=new BufferedWriter(new OutputStreamWriter(grdStream));
            grdWriter.write(info);
            grdWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        System.out.println("打印成功"+gradePath);
        return true;
    }

    /**
     *@Params: [url, which]
     * @params: url 1:题目 2:答案 3:批改
     *@Return: void
     *@Author: Likailing
     *@Date: 2021/9/28 23:00
     *@Desciption: 将文件发送到打印机
     */
    public void sendToPrinter(String name,int code){
        String url=name;
        if(url!=null){
            doPrint(url,code);
        }else{
            Log.e("File","没有找到打印的文件");
        }


    }
    /**
     *@Params: [filePath, which]
     *@Return: void
     *@Author: Likailing
     *@Date: 2021/9/28 23:03
     *@Desciption: 执行pdf转换并打印
     */
    private void doPrint(String name,int code) {
        writePdf(name,code);
        PrintManager printManager = (PrintManager) MainActivity.myContext.getSystemService(Context.PRINT_SERVICE);
        MyPrintPdfAdapter myPrintAdapter = new MyPrintPdfAdapter(folderPath+File.separator+"Print_"+code+".pdf");
        printManager.print("jobName", myPrintAdapter, null);

    }
    /**
     *@Params: [filePath, which]
     *@Return: void
     *@Author: Likailing
     *@Date: 2021/9/28 23:04
     *@Desciption: 将txt文件转换为pdf
     */
    private void writePdf(String name,int code){
        Document document=new Document(PageSize.A4, 50, 50, 50, 50);
        String text= getText(name);
        System.out.println(text);
        PdfWriter writer = null;
        try {
            writer = PdfWriter.getInstance(document, new FileOutputStream(folderPath+ File.separator+"Print_"+code+".pdf"));
            document.open();

            document.addAuthor("算了");
            document.addTitle("算了-练习题");
            document.add(new Paragraph(text));
            document.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        writer.setViewerPreferences(PdfWriter.PageModeUseThumbs);

    }
}
