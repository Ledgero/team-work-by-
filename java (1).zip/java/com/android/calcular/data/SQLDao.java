package com.android.calcular.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.android.calcular.MyApplication;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * project name: Calcular
 * Date 2021/10/24 12:21
 *
 * @PackageName: com.android.calcular.data
 * @ClassName: SQLDao
 * @Author: Likailing
 * @Version:
 * @Desciption:数据库操作类
 */
public class SQLDao {
    SQLHelper sqlHelper;
    SQLiteDatabase database;
    public SQLDao(Context context){
        sqlHelper =new SQLHelper(context,"testdb.db",2);
        database= sqlHelper.getWritableDatabase();
    }

    /**
    *@Params: []
    *@Return: List
    *@Author: Likailing
    *@Date: 2021/10/24 12:31
    *@Desciption:获取最新的学生信息
    */
    public List getNewestStuInfo(){
        List info=new ArrayList();
        Cursor cursor=database.query("StudentInfo",new String[]{"stu_grade","stu_accuracy","stu_questionCount","stu_date"},null,null,null,null,null);
        if(cursor.moveToLast()){
            info.add(cursor.getInt(0));
            info.add(cursor.getDouble(1));
            info.add(cursor.getInt(2));
            info.add(cursor.getLong(3));
        }
        Log.i("sql",info.toString());
        return info;
    }
    /**
    *@Params: []
    *@Return: List
    *@Author: Likailing
    *@Date: 2021/10/24 12:32
    *@Desciption:获取所有的学生信息
    */
    public List getAllStuInfo(){
        List<List> infos=new ArrayList<>();
        Cursor cursor=database.query("StudentInfo",new String[]{"stu_grade","stu_accuracy","stu_questionCount","stu_date"},null,null,null,null,null);
        while(cursor.moveToNext()){
            List info=new ArrayList();
            info.add(cursor.getInt(0));
            info.add(cursor.getDouble(1));
            info.add(cursor.getInt(2));
            info.add(cursor.getLong(3));
            infos.add(info);
        }
        cursor.close();
        Log.i("sql",infos.toString());
        return infos;
    }
    /**
    *@Params: []
    *@Return: java.util.List
    *@Author: Likailing
    *@Date: 2021/10/24 13:39
    *@Desciption:获取所有的学习记录
    */
    public List getAllStudyRecords(){
        List<List> records=new ArrayList<>();
        Cursor cursor=database.query("StudyHistory",new String[]{"his_code","his_time","his_timeCost","his_isFinished","his_score","his_wrong","his_type","his_amount"},null,null,null,null,null);
        while(cursor.moveToNext()){
            List record=new ArrayList();
            record.add(cursor.getInt(0));
            record.add(cursor.getLong(1));
            record.add(cursor.getInt(2));
            record.add(cursor.getInt(3));
            record.add(cursor.getInt(4));
            record.add(cursor.getInt(5));
            record.add(cursor.getString(6));
            record.add(cursor.getInt(7));
            records.add(record);
        }
        cursor.close();
        Log.i("sql",records.toString());
        return records;
    }

    public List getNewestRecord(){
        List record=new ArrayList<>();
        Cursor cursor=database.query("StudyHistory",new String[]{"his_code","his_time","his_timeCost","his_isFinished","his_score","his_wrong","his_type","his_amount"},null,null,null,null,null);
        if(cursor.moveToLast()){
            record.add(cursor.getInt(0));
            record.add(cursor.getLong(1));
            record.add(cursor.getInt(2));
            record.add(cursor.getInt(3));
            record.add(cursor.getInt(4));
            record.add(cursor.getInt(5));
            record.add(cursor.getString(6));
            record.add(cursor.getInt(7));
        }
        cursor.close();
        Log.i("sql",record.toString());
        return record;
    }
    /**
    *@Params: [datetime]
    *@Return: java.util.Date
    *@Author: Likailing
    *@Date: 2021/10/24 12:39
    *@Desciption:获取北京时间
    */
    public String getBeijingTime(Date date){
        // 北京
        SimpleDateFormat bjSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // 设置北京时区
        bjSdf.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));

        return bjSdf.format(date);
    }
    /**
    *@Params: [grade, accuracy, questionCount, date]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 13:15
    *@Desciption:增加学生信息记录
    */
    public void addStuInfo(int grade,double accuracy,int questionCount,Date date){
        Date lastDate=null;
        if(getNewestStuInfo().size()>0){
           lastDate=new Date((long)getNewestStuInfo().get(3));
        }

        ContentValues info=new ContentValues();
        info.put("stu_grade", grade);
        info.put("stu_accuracy",accuracy);
        info.put("stu_questionCount",questionCount);
        info.put("stu_date",date.getTime());
        if(lastDate==null||lastDate.getDay()!=date.getDay()){//如果上条记录不为同一天
            database.insert("StudentInfo",null,info);
        }else{
            database.update("StudentInfo",info,"stu_date=?",new String[]{String.valueOf(getNewestStuInfo().get(3))});
        }

    }
    /**
    *@Params: [code, time, timeCost, isFinished, score, wrong, type]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 13:24
    *@Desciption:增加学习记录
    */
    public void addStudyRecord(int code,long time,int timeCost,boolean isFinished,int score,int wrong,String type,int amount){
        ContentValues record=new ContentValues();
        record.put("his_code",code);
        record.put("his_time",time);
        record.put("his_timeCost",timeCost);
        record.put("his_isFinished",isFinished);
        record.put("his_score",score);
        record.put("his_wrong",wrong);
        record.put("his_type",type);
        record.put("his_amount",amount);
        database.insert("StudyHistory",null,record);
    }
    /**
    *@Params: [code, time, timeCost, isFinished, score, wrong, type, amount]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 17:07
    *@Desciption:编辑某条记录，根据his_code寻找记录
    */
    public void editStudyRecord(int code,long time,int timeCost,boolean isFinished,int score,int wrong,String type,int amount){
        ContentValues record=new ContentValues();
        record.put("his_code",code);
        record.put("his_time",time);
        record.put("his_timeCost",timeCost);
        record.put("his_isFinished",isFinished);
        record.put("his_score",score);
        record.put("his_wrong",wrong);
        record.put("his_type",type);
        record.put("his_amount",amount);
        database.update("StudyHistory",record,"his_code=?",new String[]{String.valueOf(code)});
    }


    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 13:39
    *@Desciption:清空所有记录
    */
    public void clearData(){
        database.execSQL("delete from StudentInfo");
        database.execSQL("delete from StudyHistory");
    }
}
