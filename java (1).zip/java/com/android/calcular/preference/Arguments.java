package com.android.calcular.preference;

import com.android.calcular.service.ArgumentWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * project name: Calcular
 * Date 2021/10/24 15:09
 *
 * @PackageName: com.android.calcular.preference
 * @ClassName: Arguments
 * @Author: Likailing
 * @Version:
 * @Desciption:类型对应的参数预设
 */
public class  Arguments{
    public static final ArgumentWrapper ARG_ORAL_1_1=new com.android.calcular.service.ArgumentWrapper(false,1,1,new int[][]{{1,0,0,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{5,5,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_1_2=new com.android.calcular.service.ArgumentWrapper(false,3,1,new int[][]{{0,2,0,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{5,5,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_1_3=new com.android.calcular.service.ArgumentWrapper(false,3,1,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_1_4=new com.android.calcular.service.ArgumentWrapper(3,2,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{10,10,10,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_1_5=new com.android.calcular.service.ArgumentWrapper(3,2,new int[][]{{1,2,0,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{10,10,10,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_1_6=new com.android.calcular.service.ArgumentWrapper(3,2,new int[][]{{1,2,0,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{20,20,20,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_1_7=new com.android.calcular.service.ArgumentWrapper(3,2,new int[][]{{1,2,0,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{100,100,100,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_1_8=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,2,0,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{100,100,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_1_9=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{1,0,0,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{100,100,0,0},true,false);

    public static final ArgumentWrapper ARG_ORAL_2_1=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{0,0,0,0},new int[]{10,10,0,0},new int[]{100,100,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_2_2=new com.android.calcular.service.ArgumentWrapper(false,3,1,new int[][]{{0,0,3,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_2_3=new com.android.calcular.service.ArgumentWrapper(23,3,2,new int[][]{{1,0,3,0},{0,2,3,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{10,10,10,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_2_4=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,0,4},{0,0,0,0}},new int[]{0,0,0,0},new int[]{10,0,0,0},new int[]{100,10,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_2_5=new com.android.calcular.service.ArgumentWrapper(25,3,2,new int[][]{{1,0,0,4},{2,0,0,4}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{10,10,10,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_2_6=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{0,0,0,0},new int[]{100,100,0,0},new int[]{1000,1000,0,0},true,false);

    public static final ArgumentWrapper ARG_ORAL_3_1=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,0,4},{0,0,0,0}},new int[]{0,0,0,0},new int[]{10,0,0,0},new int[]{100,10,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_3_2=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,0,4},{0,0,0,0}},new int[]{0,0,0,0},new int[]{100,0,0,0},new int[]{1000,10,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_3_3=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,3,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{10,0,0,0},new int[]{100,10,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_3_4=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,3,0},{0,0,0,0}},new int[]{0,0,0,0},new int[]{10,10,0,0},new int[]{100,100,0,0},true,false);
    public static final ArgumentWrapper ARG_ORAL_3_5=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{1,1,0,0},new int[]{0,0,0,0},new int[]{1,1,0,0},false,false);

    public static final ArgumentWrapper ARG_ORAL_4_1=new com.android.calcular.service.ArgumentWrapper(3,3,new int[][]{{1,2,3,4},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{10,10,10,10},true,true);
    public static final ArgumentWrapper ARG_ORAL_4_2=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{1,1,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},false,false);

    public static final ArgumentWrapper ARG_ORAL_5_1=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,0,4},{0,0,0,0}},new int[]{1,0,0,0},new int[]{0,2,0,0},new int[]{50,20,0,0},false,false);
    public static final ArgumentWrapper ARG_ORAL_5_2=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,3,0},{0,0,0,4}},new int[]{1,1,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},false,false);
    public static final ArgumentWrapper ARG_ORAL_5_3=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{22,22,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},false,false);
    public static final ArgumentWrapper ARG_ORAL_5_4=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{1,0,0,0},{0,2,0,0}},new int[]{21,21,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},false,false);
    public static final ArgumentWrapper ARG_ORAL_5_5=new com.android.calcular.service.ArgumentWrapper(3,3,new  int[][]{{1,2,0,0},{0,0,0,0}},new int[]{20,20,20,20},new int[]{0,0,0,0},new int[]{10,10,10,10},false,false);

    public static final ArgumentWrapper ARG_ORAL_6_1=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,3,0},{0,0,0,0}},new int[]{20,0,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},false,false);
    public static final ArgumentWrapper ARG_ORAL_6_2=new com.android.calcular.service.ArgumentWrapper(3,1,new int[][]{{0,0,3,0},{0,0,0,0}},new int[]{20,20,0,0},new int[]{0,0,0,0},new int[]{10,10,0,0},false,false);
    public static final ArgumentWrapper ARG_ORAL_6_3=new com.android.calcular.service.ArgumentWrapper(3,3,new int[][]{{1,2,3,4},{0,0,0,0}},new int[]{0,0,0,0},new int[]{0,0,0,0},new int[]{20,20,20,20},false,true);


    public static ArgumentWrapper getRandomArgument() {
        ArgumentWrapper[] Arg =new ArgumentWrapper[50];
        Arg[0] = ARG_ORAL_1_1;
        Arg[1] = ARG_ORAL_1_2;
        Arg[2] = ARG_ORAL_1_3;
        Arg[3] = ARG_ORAL_1_4;
        Arg[4] = ARG_ORAL_1_5;
        Arg[5] = ARG_ORAL_1_6;
        Arg[6] = ARG_ORAL_1_7;
        Arg[7] = ARG_ORAL_1_8;
        Arg[8] = ARG_ORAL_1_9;
        Arg[9] = ARG_ORAL_2_1;
        Arg[10] = ARG_ORAL_2_2;
        Arg[11] = ARG_ORAL_2_3;
        Arg[12] = ARG_ORAL_2_4;
        Arg[13] = ARG_ORAL_2_5;
        Arg[14] = ARG_ORAL_2_6;
        Arg[15] = ARG_ORAL_3_1;
        Arg[16] = ARG_ORAL_3_2;
        Arg[17] = ARG_ORAL_3_3;
        Arg[18] = ARG_ORAL_3_4;
        Arg[19] = ARG_ORAL_3_5;
        Arg[20] = ARG_ORAL_4_1;
        Arg[21] = ARG_ORAL_4_2;
        Arg[22] = ARG_ORAL_5_1;
        Arg[23] = ARG_ORAL_5_2;
        Arg[24] = ARG_ORAL_5_3;
        Arg[25] = ARG_ORAL_5_4;
        Arg[26] = ARG_ORAL_5_5;
        Arg[27] = ARG_ORAL_6_1;
        Arg[28] = ARG_ORAL_6_2;
        Arg[29] = ARG_ORAL_6_3;
        return Arg[(int)(Math.random()*30)];
    }
}




