package com.android.calcular;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;

import com.android.calcular.adapter.ViewPageAdapter;
import com.android.calcular.ui.PracticeFragment;
import com.android.calcular.ui.PracticePageFragment;
import com.android.calcular.ui.ResultPageFragment;

import java.util.ArrayList;
import java.util.List;

public class PracticeActivity extends AppCompatActivity {
    static List<Fragment> fragmentList1=new ArrayList<>();
    static List<Fragment> fragmentList2=new ArrayList<>();
    static ViewPager2 viewPager2;
    static boolean isFinished=false;
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 19:47
    *@Desciption:切换到结果页面
    */
    public static void goToResultPage(){
        isFinished=true;
        viewPager2.setCurrentItem(1);
    }

    public static void goToExcercisePage(){

        isFinished=false;
        viewPager2.setCurrentItem(0);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practice);
        this.setTitle("练习进行中");
        viewPager2=findViewById(R.id.viewPagePractice);
        fragmentList1.add(new PracticePageFragment());
        fragmentList1.add(new ResultPageFragment());
        viewPager2.setAdapter(ViewPageAdapter.start(this,fragmentList1));

        viewPager2.setOffscreenPageLimit(1);
    }

}