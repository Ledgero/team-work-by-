package com.android.calcular.adapter;

import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
/**
  *Date 2021/9/28 22:36
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: pdf打印功能适配器
  */
public class MyPrintPdfAdapter extends PrintDocumentAdapter {
    private String mFilePath;

    public MyPrintPdfAdapter(String file) {
        this.mFilePath = file;
    }
    /**
    *@Params: [oldAttributes, newAttributes, cancellationSignal, callback, extras]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:08
    *@Desciption: 指定正在创建的文档类型，并计算打印作业的总页数，并提供有关打印页面大小的信息
    */
    @Override
    public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                         CancellationSignal cancellationSignal,
                         LayoutResultCallback callback, Bundle extras) {
        if (cancellationSignal.isCanceled()) {
            callback.onLayoutCancelled();
            return;
        }
        PrintDocumentInfo info = new PrintDocumentInfo.Builder("name")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .build();
        callback.onLayoutFinished(info, true);
    }
    /**
    *@Params: [pages, destination, cancellationSignal, callback]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:08
    *@Desciption: 将每个请求的内容页面呈现为多页PDF文档文件
    */
    @Override
    public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                        CancellationSignal cancellationSignal,
                        WriteResultCallback callback) {
        InputStream input = null;
        OutputStream output = null;

        try {

            input = new FileInputStream(mFilePath);
            output = new FileOutputStream(destination.getFileDescriptor());

            byte[] buf = new byte[1024];
            int bytesRead;

            while ((bytesRead = input.read(buf)) > 0) {
                output.write(buf, 0, bytesRead);
            }

            callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                output.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                input.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}