package com.android.calcular.control;

import android.content.Context;
import android.util.Log;
import android.util.Printer;

import com.android.calcular.PracticeActivity;
import com.android.calcular.data.FileDao;
import com.android.calcular.data.SQLDao;
import com.android.calcular.service.ArgumentWrapper;
import com.android.calcular.service.CheckerService;
import com.android.calcular.service.ExpressionWrapper;
import com.android.calcular.service.FractionWrapper;
import com.android.calcular.service.GeneratorService;
import com.android.calcular.service.InfoAccessService;
import com.android.calcular.ui.PracticeFragment;
import com.android.calcular.ui.PracticePageFragment;
import com.android.calcular.ui.ResultPageFragment;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * project name: Calcular
 * Date 2021/10/23 15:32
 *
 * @PackageName: com.android.calcular.control
 * @ClassName: PracticeAction
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class PracticeAction {
    private SQLDao sqlDao;
    Context context;
    public PracticeAction(Context context){

        sqlDao=new SQLDao(context);
        this.context=context;
    }
    /**
    *@Params: [grade]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 15:07
    *@Desciption: 更新年级信息
    */
    public void updateGrade(int grade){
        List last=sqlDao.getNewestStuInfo();
        sqlDao.addStuInfo(grade,(double)last.get(1),(int)last.get(2),new Date((long)last.get(3)));
    }
    /**
    *@Params: [arg]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/24 15:11
    *@Desciption:开始生成题目
    */
    public void startGenerating(ArgumentWrapper arg){
        GeneratorService generator=new GeneratorService();
        generator.generate(arg);
        Log.i("Generate",generator.getList().toString());
        PracticePageFragment.setExpList(generator.getList());
    }

    public void checkAnswers(List<ExpressionWrapper> expList,List<FractionWrapper> answerList,int time){
        CheckerService checkerService=new CheckerService();
        InfoAccessService infoAccessService=new InfoAccessService(context);
        boolean[] results=checkerService.checkAnswer(expList,answerList);
        int score=0;
        int wrongs=0;
        int index=0;
        StringBuilder swrongs=new StringBuilder();
        while(index<results.length){
            if(results[index]){
                score+=100/results.length;
            }else{
                System.out.println(answerList.toString());
                String ans="未填写";
                if(answerList.get(index)!=null){
                    ans=answerList.get(index).toString();
                }
                swrongs.append(expList.get(index).getQuest()+"="+ans+"\n");
                wrongs++;
            }
            index++;
        }
        if(wrongs==0){
            score=100;
        }
        ResultPageFragment.setInfos(score,time,swrongs.toString());
        infoAccessService.saveRecordInfo(getRecordCode(),System.currentTimeMillis(),time,true,score,wrongs, PracticeFragment.oralType,expList.size());
        Log.i("sql","记录已保存");
        Log.i("sql","保存的记录："+sqlDao.getNewestRecord());
        PracticeActivity.goToResultPage();
    }
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/27 12:46
    *@Desciption:开启打印服务
    */
    public void startPrinter(ArgumentWrapper arg){
        GeneratorService generatorService=new GeneratorService();
        FileDao fileDao=new FileDao();
        InfoAccessService infoAccessService=new InfoAccessService(context);
        generatorService.generate(arg);
        int code=getRecordCode();
        infoAccessService.printQuestions(code,generatorService.getList(),new ArrayList<FractionWrapper>());
        System.out.println("h"+code);
        fileDao.sendToPrinter("h"+code,1);

    }

    public  int getRecordCode(){
        int code=0;
        Date date=new Date();
        code+= date.getSeconds();
        code+=date.getMinutes()*100;
        code+=date.getHours()*10000;
        code+=date.getDay()*1000000;
              return code;

    }

}
