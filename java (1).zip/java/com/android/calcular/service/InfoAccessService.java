package com.android.calcular.service;

import android.content.Context;
import android.icu.text.IDNA;

import com.android.calcular.data.FileDao;
import com.android.calcular.data.SQLDao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * project name: Calcular
 * Date 2021/10/26 16:33
 *
 * @PackageName: com.android.calcular.service
 * @ClassName: InfoAccessService
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class InfoAccessService {
    private Context context;
    public InfoAccessService(Context context){
        this.context=context;
    }
    /**
    *@Params: [code, expList, answers]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 16:56
    *@Desciption: 将题目、用户输入的答案以及正确情况保存在文件中
    */
    public void printQuestions(int code,List<ExpressionWrapper> expList,List<FractionWrapper> answers){
        FileDao fileDao=new FileDao();
        Iterator<ExpressionWrapper> expListIterator = expList.iterator();
        Iterator<FractionWrapper> answersIterator = answers.iterator();
        StringBuilder strArrStrings = new StringBuilder();
        if(answers.size()>0){

            int index =0;//记录题目序号
            while(expListIterator.hasNext()){
                index++;
                ExpressionWrapper exp = expListIterator.next();
                FractionWrapper answer = answersIterator.next();
                if(exp.result.equals(answer)){
                    strArrStrings.append(index+". "+exp.getQuest()+"="+answer.toString()+"T"+"\n");
                }else{
                    strArrStrings.append(index+". "+exp.getQuest()+"="+answer.toString()+"F"+"\n");
                }
            }
            String message = strArrStrings.toString();
            fileDao.printFile("h"+code,message);
        }else{
            int index =0;//记录题目序号
            while(expListIterator.hasNext()){
                index++;
                    strArrStrings.append(index+". "+expListIterator.next().getQuest()+"="+"\n");
            }
            String message = strArrStrings.toString();
            System.out.println("打印："+message);
            fileDao.printFile("h"+code,message);
        }


    }
    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 16:57
    *@Desciption:将学习记录信息保存在数据库中,记录编号第一次出现时创建时新建记录，编号已存在时编辑过去的记录
    */
    public void saveRecordInfo(int code,long time,int timeCost,boolean isFinished,int score,int wrong,String type,int amount){
        //TODO
        SQLDao sqlDao=new SQLDao(context);
        boolean addsql = true;
        if(sqlDao.getAllStudyRecords().isEmpty()){
            sqlDao.addStudyRecord(code,time,timeCost,isFinished,score,wrong,type,amount);
        }
        else{
            Iterator<List> L = sqlDao.getAllStudyRecords().iterator();
            while (L.hasNext()){
                if(((Integer) (L.next().get(0))).equals(new Integer(code))){
                    addsql=false;
                    break;
                }
            }
            if(addsql) {
                sqlDao.addStudyRecord(code, time, timeCost, isFinished, score, wrong, type, amount);
            }
            else {
                sqlDao.editStudyRecord(code,time,timeCost,isFinished,score,wrong,type,amount);
            }
        }
    }
    /**
    *@Params: [grade, accuracy, questionCount, date]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/10/26 17:12
    *@Desciption:保存学生用户信息到数据库中
    */
    public void saveStudentInfo(int grade, double accuracy, int questionCount, Date date){
        //TODO
        SQLDao sqlDao=new SQLDao(context);
            sqlDao.addStuInfo(grade,accuracy,questionCount,date);
    }
    /**
    *@Params: []
    *@Return: long
    *@Author: Likailing
    *@Date: 2021/10/26 17:15
    *@Desciption:获取当前的时间（毫秒）
    */
    private long getCurrentTimeLong(){
        return System.currentTimeMillis();
    }
    /**
    *@Params: []
    *@Return: java.util.Date
    *@Author: Likailing
    *@Date: 2021/10/26 17:15
    *@Desciption:获取当前的时间（Date对象）
    */
    private Date getCurrentTimeDate(){
        Date date=new Date(System.currentTimeMillis());
        return date;
    }
}
