package com.android.calcular.service;

import java.util.Objects;
/**
 *Date 2021/9/28 22:34
 *@Author: Likailing
 *@Version: 1.0
 *@Desciption: 分数的包装类
 */
public class FractionWrapper implements Comparable{
    public int son;
    public int mother;
    public boolean isDecimal=false;
    public FractionWrapper(int son, int mother) {
        if(mother<0){
            son=-son;
            mother=-mother;
        }
        this.son = son;
        this.mother = mother;
    }

    public FractionWrapper(int son) {
        this.son = son;
        this.mother=1;
    }

    public void setDecimal(){
        isDecimal=true;
    }
    /**
     *@Params: [o]
     *@Return: int
     *@Author: Likailing
     *@Date: 2021/9/28 22:54
     *@Desciption: 比较与另一个分数的大小
     */
    @Override
    public int compareTo(Object o) {
        if(o instanceof FractionWrapper){
            FractionWrapper other=(FractionWrapper) o;
            return (int)(this.son*other.mother-other.son*this.mother);


        }else{
            return 0;
        }
    }
    /**
     *@Params: [o]
     *@Return: int
     *@Author: Likailing
     *@Date: 2021/9/28 22:54
     *@Desciption: 比较分母大小
     */
    public int compareMother(Object o) {
        if(o instanceof FractionWrapper){
            FractionWrapper other=(FractionWrapper) o;
            if( (int)(this.mother-other.mother)==0) {
                return 0;
            }
            if( (int)(this.mother-other.mother)!=0) {
                return 1;
            }
        }
        return 2;
    }
    /**
     *@Params: [o]
     *@Return: boolean
     *@Author: Likailing
     *@Date: 2021/9/28 22:55
     *@Desciption: 比较与另一个分数是否相等
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {return true;}
        if (o == null || getClass() != o.getClass()){ return false;}
        FractionWrapper fractionWrapper = (FractionWrapper) o;
        return son == fractionWrapper.son && mother == fractionWrapper.mother;
    }
    /**
     *@Params: []
     *@Return: java.lang.String
     *@Author: Likailing
     *@Date: 2021/9/28 22:55
     *@Desciption: 获取分数的字符串形式
     */
    @Override
    public String toString() {
        if(mother==1){
            //整数
            return String.valueOf(son);
        }else if(isDecimal){
            return String.valueOf((double)son/mother);
        }
        return son+"/"+mother;
    }
    /**
     *@Params: []
     *@Return: int
     *@Author: Likailing
     *@Date: 2021/9/28 22:56
     *@Desciption: 获取分数的哈希值
     */
    @Override
    public int hashCode() {
        return Objects.hash(son, mother);
    }

}
