package com.android.calcular.service;

import android.provider.ContactsContract;

import java.util.*;
import java.util.concurrent.*;
/**
  *Date 2021/9/28 22:34
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 表达式的包装类
  */
public class ExpressionWrapper {
    /**
     * 计算类对象
     */
    private CalculatorService calculatorService =new CalculatorService();
    /**
     * 当前元素下标
     */
    private int index=0;
    /**
     * 题号
     */
    public int number;
    /**
     * 计算算式列
     */
    List myUnits = new ArrayList();
    /**
     * 原算式列
     */
    List orinalUnits=new ArrayList();
    /**
     * 查重算式列
     */
    List checkUnits=new ArrayList();
    /**
     * 结果
     */
    public FractionWrapper result=new FractionWrapper(0);
    /**
     * 是否为基算式列
     */
    private boolean original;
    /**
     * 算式是否合法
     */
    public boolean valid=true;
    /**
    *@Params: [units]
    *@Return:
    *@Author: Likailing
    *@Date: 2021/10/3 16:45
    *@Desciption: 通过集合创建题目
    */
    public ExpressionWrapper(List units) {
        this.original=true;
        orinalUnits=units;
        seperate(units);
        ExpressionWrapper expressionWrapper =this;
        //超时中断
        Callable<String> task = new Callable<String>() {
            @Override
            public String call() throws Exception{
                //执行耗时代码
                result= calculatorService.calculate(expressionWrapper);
                if(result==null){
                    valid=false;
                }
                return "";
            }
        };
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<String> future = executorService.submit(task);
        try {
            //设置超时时间
            String rst = future.get(3, TimeUnit.SECONDS);
            //System.out.println(rst);
        } catch (TimeoutException e) {
            System.out.println("执行超时");
            valid=false;
        } catch(Exception e){
            System.out.println("获取数据异常," + e.getMessage());
            valid=false;
        }finally {
            executorService.shutdown();
        }

    }
    /**
    *@Params: [line]
    *@Return:
    *@Author: Likailing
    *@Date: 2021/10/3 16:45
    *@Desciption:用于读取单行文本并创建题目对象,适用于Checker
    */
    public ExpressionWrapper(String line){
        this.original=true;
        List units=new ArrayList();
        int index=0;
        StringBuilder numb=new StringBuilder();
        while(line.charAt(index)!='.'){
            numb.append(line.charAt(index));
            index++;
        }
        number=Integer.parseInt(numb.toString());
        index++;
        StringBuilder nums=new StringBuilder();
        int son,mother;//分子和分母
        while(index<line.length()){
            if(line.charAt(index)>='0'&&line.charAt(index)<='9'&&nums.length()>0){
                nums.append(line.charAt(index));
                index++;
            }else if(line.charAt(index)>='0'&&line.charAt(index)<='9'&&nums.length()==0){
                nums.append(line.charAt(index));
                index++;
            }else if(line.charAt(index)!=' '){
                char value=line.charAt(index);
                switch(value){
                    case '+':
                    case '-':
                    case '*':
                        if(nums.length()>0){
                            FractionWrapper fractionWrapper =new FractionWrapper(Integer.valueOf(nums.toString()));
                            units.add(fractionWrapper);
                            units.add(parseValue(value));
                            nums=new StringBuilder();
                        }else{
                            units.add(parseValue(value));
                        }

                        index++;
                        break;
                    case '/':


                        son=Integer.valueOf(nums.toString());
                        nums=new StringBuilder();
                        index++;
                        while(index<line.length()&&line.charAt(index)>='0'&&line.charAt(index)<='9'){
                            nums.append(line.charAt(index));
                            index++;
                        }
                        if(nums.length()==0){
                            units.add(new FractionWrapper(son));
                            units.add(Value.DIVIDE);
                        }else{
                            mother=Integer.valueOf(nums.toString());
                            units.add(new FractionWrapper(son,mother));
                            nums=new StringBuilder();
                        }

                        break;
                    case '÷':
                        if(nums.length()>0){
                            units.add(new FractionWrapper(Integer.parseInt(nums.toString())));
                        }

                        units.add(Value.DIVIDE);
                        nums=new StringBuilder();
                        index++;
                        break;
                    case '(':
                        units.add(parseValue(value));
                        index++;
                        break;
                    case ')':
                        if(nums.length()>0){
                            units.add(new FractionWrapper(Integer.parseInt(nums.toString())));
                            nums=new StringBuilder();
                        }
                        units.add(parseValue(value));
                        index++;
                        break;

                    default:
                        break;
                }
            }else{
                index++;
            }



        }
        if(nums.length()>0){
            units.add(new FractionWrapper(Integer.parseInt(nums.toString())));
        }

        orinalUnits=units;
        seperate(units);

        ExpressionWrapper expressionWrapper =this;
        //超时中断
        Callable<String> task = new Callable<String>() {
            @Override
            public String call() throws Exception{
                //执行耗时代码
                result= calculatorService.calculate(expressionWrapper);
                if(result==null){
                    valid=false;
                }
                return "success";
            }
        };
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<String> future = executorService.submit(task);
        try {
            //设置超时时间
            String rst = future.get(3, TimeUnit.SECONDS);
            System.out.println(rst);
        } catch (TimeoutException e) {
            System.out.println("执行超时");
            valid=false;
        } catch(Exception e){
            System.out.println("获取数据异常," + e.getMessage());
            valid=false;
        }finally {
            executorService.shutdown();
        }


    }
    /**
    *@Params: []
    *@Return:
    *@Author: Likailing
    *@Date: 2021/10/3 16:46
    *@Desciption: 仅内部使用
    */
    public ExpressionWrapper(){
        original=false;

    }

    /**
    *@Params: [c]
    *@Return: com.android.arithmeticexcercise.Value
    *@Author: Likailing
    *@Date: 2021/9/28 22:50
    *@Desciption: 解析符号字符
    */
    private Value parseValue(char c){
        switch(c){
            case '+':
                return Value.ADD;

            case '-':
                return  Value.MINUS;

            case '*':
                return  Value.MULTIPLY;
            case '/':
                return Value.DIVIDE_FRA;
            case '(':
                return Value.BRACKET_LEFT;
            case ')':
                return Value.BRACKET_RIGHT;
            case '÷':
                return  Value.DIVIDE;
            default:
                break;
        }
        return null;
    }
    /**
    *@Params: [oldList]
    *@Return: java.util.List<T>
    *@Author: Likailing
    *@Date: 2021/9/28 22:51
    *@Desciption: 去除集合中的空元素
    */
    public static <T> List<T> removeNull(List<? extends T> oldList) {
        oldList.removeAll(Collections.singleton(null));
        return (List<T>) oldList;
    }

    /**
     * @author 12042
     * @Desciption 单元化分割算式
     * @Date 16:14 2021/9/24
     * @Param [units]
     * @return void
     **/
    private void seperate(List units) {
        LinkedList queue=new LinkedList();
        LinkedList queue2=new LinkedList();
        while(index<units.size()){
            if(units.get(index) instanceof FractionWrapper){
                queue.add(units.get(index));
                queue2.add(units.get(index));
                index++;
            }else{
                Value value=(Value)units.get(index);
                switch(value){
                    case ADD:
                    case MINUS:
                        myUnits.addAll(queue);
                        myUnits.add(value);
                        queue.clear();

                        checkUnits.addAll(queue2);
                        checkUnits.add(value);
                        queue2.clear();

                        index++;
                        break;
                    case MULTIPLY:
                    case DIVIDE:
                        queue.add(value);
                        queue2.add(value);
                        index++;
                        ExpressionWrapper newUnit=detect(units,queue,1);

                        queue.add(newUnit);
                        queue2.add(newUnit);
                        break;
                    case BRACKET_LEFT:

                        index++;
                        ExpressionWrapper sonUnit=detect(units,queue,2);
                        sonUnit.simplify();
                        //满足可去括号前置条件：括号左边为加减号或左括号为题目开头
                        //满足可去括号后置条件：右括号为末尾或者括号右侧为加减号
                        boolean condition1=myUnits.isEmpty()|| (myUnits.get(myUnits.size()-1)==Value.ADD||myUnits.get(myUnits.size()-1)==Value.MINUS);
                        boolean condition2=index>=units.size()||(units.get(index)==Value.ADD||units.get(index)==Value.MINUS);
                        boolean condition3=!(sonUnit.myUnits.contains(Value.MULTIPLY)||sonUnit.myUnits.contains(Value.DIVIDE));
                        if(condition1&&condition2&&condition3){

                            queue.addAll(sonUnit.myUnits);

                        }

                        else{
                            queue.add(sonUnit);
                        }


                        break;
                    case BRACKET_RIGHT:
                        break;
                    default:
                        break;
                }
            }

        }
        if(queue.size()>0){

            myUnits.addAll(queue);
            checkUnits.addAll(queue);

        }
        removeNull(myUnits);
        simplify();

    }
    /**
     * @author 12042
     * @Desciption 探测乘除或括号单元
     * @Date 16:14 2021/9/24
     * @Param [units, queue, mode]
     * @return com.teachertom.appTest.Expression
     **/
    private ExpressionWrapper detect(List units, LinkedList queue, int mode){//mode:1乘号探测 2左右括号探测
        ExpressionWrapper newUnit=null;
        while(index<units.size()){
            if(units.get(index) instanceof FractionWrapper){
                queue.add(units.get(index));
                index++;
            }else{
                Value value=(Value)units.get(index);
                switch(value){
                    case ADD:
                    case MINUS:
                        if(mode==1){
                            if(newUnit==null){
                                newUnit=new ExpressionWrapper();

                            }
                            newUnit.myUnits.addAll(queue);
                            queue.clear();
                            return newUnit;
                        }else if(mode==2){
                            if(newUnit==null){
                                newUnit=new ExpressionWrapper();
                            }
                            queue.add(units.get(index));
                            newUnit.myUnits.addAll(queue);
                            queue.clear();
                            index++;
                        }

                        break;


                    case MULTIPLY:
                    case DIVIDE:
                       if(mode==1){
                           queue.add(value);
                           index++;

                        }else if(mode==2){
                            queue.add(value);
                            index++;
                            ExpressionWrapper sonUnit=detect(units,queue,1);
                            queue.add(sonUnit);
                            removeNull(queue);
                        }
                        break;


                    case BRACKET_LEFT:
                        if(mode==1){
                            index++;
                            newUnit = new ExpressionWrapper();
                            newUnit.myUnits.addAll(queue);
                            queue.clear();
                            ExpressionWrapper sonUnit = detect(units, queue, 2);
                            sonUnit.simplify();
                            newUnit.myUnits.add(sonUnit);
                        }else{
                            index++;
                            ExpressionWrapper sonUnit = detect(units, queue, 2);
                            //满足可去括号前置条件：1:括号左边为加减号或左括号为题目开头,右括号为末尾或者括号右侧为加减号 2:括号内部只含乘除号并且括号左右有乘除号
                            boolean condition1=(myUnits.isEmpty()|| (myUnits.get(myUnits.size()-1)==Value.ADD||myUnits.get(myUnits.size()-1)==Value.MINUS));
                            boolean condition2=(index>=units.size()-1||(units.get(index)==Value.ADD||units.get(index)==Value.MINUS));
                            boolean condition3=(!(sonUnit.myUnits.contains(Value.MULTIPLY)||sonUnit.myUnits.contains(Value.DIVIDE)));
                            if(condition1 &&condition2 &&condition3){
                                queue.addAll(sonUnit.myUnits);
                            }else if((sonUnit.myUnits.contains(Value.MULTIPLY)||sonUnit.myUnits.contains(Value.DIVIDE))){
                                queue.addAll(sonUnit.myUnits);
                            }
                            else{
                                queue.add(sonUnit);
                            }
                        }
                        break;


                    case BRACKET_RIGHT:
                        if(mode==2){
                            if (newUnit == null) {
                                newUnit=new ExpressionWrapper();
                            }

                            newUnit.myUnits.addAll(queue);
                            queue.clear();
                            newUnit.simplify();
                            index++;
                            return newUnit;
                        }
                        if(mode==1){
                            if(queue.size()>0&&newUnit==null){
                                newUnit=new ExpressionWrapper();
                                newUnit.myUnits.addAll(queue);
                                newUnit.simplify();
                                queue.clear();
                            }
                            return newUnit;
                        }

                    default:
                        break;


                }
            }

        }
        if(queue.size()>0){
            newUnit=new ExpressionWrapper();
            newUnit.myUnits.addAll(queue);
            queue.clear();
        }
        newUnit.simplify();
        return newUnit;
    }



    /**
     * @author 12042
     * @Desciption 去除多余的嵌套
     * @Date 10:41 2021/9/24
     * @Param []
     * @return void
     **/
    private void simplify(){
        int i=0;


        Iterator iterator=myUnits.iterator();
        while(iterator.hasNext()){
            Object cur=iterator.next();
            if(cur instanceof ExpressionWrapper &&((ExpressionWrapper) cur).myUnits.size()==1){
                myUnits.set(i,((ExpressionWrapper) cur).myUnits.get(0));
            }
            i++;
        }
        if(myUnits.size()==1&&myUnits.get(0) instanceof ExpressionWrapper){
            myUnits=((ExpressionWrapper)(myUnits.get(0))).myUnits;

        }




    }
    /**
    *@Params: []
    *@Return: java.lang.String
    *@Author: Likailing
    *@Date: 2021/9/28 22:53
    *@Desciption: 将算式以分块模式输出
    */
    @Override
    public String toString() {
        if(original){
            return "Expression{" +"amount="+myUnits.size()+","+
                    "Units=" + myUnits +
                    ", result=" + result +
                    ",hashcode="+hashCode()+
                    '}';
        }else{
            return " "+myUnits+" ";
        }

    }

    /**
    *@Params: []
    *@Return: java.lang.String
    *@Author: Likailing
    *@Date: 2021/9/28 22:53
    *@Desciption: 获取题目表达式的输出字符串
    */
    public String getQuest(){
        StringBuilder outer=new StringBuilder();
        Iterator iterator= orinalUnits.iterator();
        while(iterator.hasNext()){
            Object o=iterator.next();
            if(o instanceof FractionWrapper){
                outer.append(o);
            }else{
                Value value=(Value)o;
                switch(value){
                    case BRACKET_RIGHT : outer.append(')');break;
                    case BRACKET_LEFT : outer.append('(');break;
                    case ADD : outer.append('+');break;
                    case MINUS : outer.append('-');break;
                    case MULTIPLY : outer.append('*');break;
                    case DIVIDE : outer.append('÷');break;
                    default:break;
                }
            }
        }
        return outer.toString();
    }

    /**
     * @author likailing
     * @Desciption 判断题目是否相等
     * @Date 9:43 2021/9/24
     * @Param [o]
     * @return boolean
     **/
    @Override
    public boolean equals(Object o) {
        if (this == o)
        {return true;}
        if (o == null || getClass() != o.getClass())
        {return false;}
        ExpressionWrapper that = (ExpressionWrapper) o;
        if(!result.equals(that.result)||myUnits.size()!=that.myUnits.size()){
            return false;
        }

        List copy=new ArrayList(Arrays.asList(new Object[myUnits.size()]));
        Collections.copy(copy,myUnits);
        Iterator iterator= that.myUnits.iterator();
        while(iterator.hasNext()){
            Object ob=iterator.next();
            if(!copy.contains(ob)){
                return false;
            }else {
                copy.remove(ob);
            }
        }
        return true;
    }

    /**
    *@Params: []
    *@Return: int
    *@Author: Likailing
    *@Date: 2021/9/28 22:54
    *@Desciption: 表达式的哈希值
    */
    @Override
    public int hashCode() {
        int hash=0;
        Iterator iterator=myUnits.iterator();
        while(iterator.hasNext()){
            Object o=iterator.next();
            if(o instanceof FractionWrapper ||o instanceof Value){
                hash+=Objects.hash(o)*Objects.hash(o);
            }else if(o instanceof ExpressionWrapper){
                hash+=o.hashCode();
            }
        }
        return hash;
    }
    final int INTEGER=1;
    final int FRACTION=2;
    final int DECIMAL=3;
    public int getAnswerType(){
        if(result.mother==1){
            return INTEGER;
        }else if(result.isDecimal){
            return DECIMAL;
        }else if(!result.isDecimal){
            return  FRACTION;
        }
        return 0;
    }
}
