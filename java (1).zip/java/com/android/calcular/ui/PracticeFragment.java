package com.android.calcular.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.calcular.PracticeActivity;
import com.android.calcular.R;
import com.android.calcular.control.PracticeAction;
import com.android.calcular.data.SQLDao;
import com.android.calcular.preference.Arguments;
import com.android.calcular.preference.Types;
import com.android.calcular.service.ArgumentWrapper;

import java.util.Date;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PracticeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PracticeFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private ArgumentWrapper argumentOral;
    private ArgumentWrapper argumentHand;
    private PracticeAction practiceAction;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private View view;
    private Spinner spinnerGrade;
    private Spinner spinnerOral;
    private Spinner spinnerHand;
    private Button buttonOralPrint;
    private Button buttonOralStart;
    private Button buttonHandPrint;
    private Button buttonHandStart;
    private EditText editTextOral;
    private EditText editTextHand;
    public static String oralType;
    public static String handType;
    public PracticeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PracticeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static PracticeFragment newInstance(String param1, String param2) {
        PracticeFragment fragment = new PracticeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_practice,null);

        spinnerGrade=view.findViewById(R.id.spinner_grade);
        spinnerHand=view.findViewById(R.id.spinner_handtype);
        spinnerOral=view.findViewById(R.id.spinner_oraltype);

        buttonOralPrint=view.findViewById(R.id.button_oralPrint);
        buttonOralStart=view.findViewById(R.id.button_oralStart);
        buttonHandPrint=view.findViewById(R.id.button_handPrint);
        buttonHandStart=view.findViewById(R.id.button_handStart);

        editTextOral=view.findViewById(R.id.editText_oralNumber);
        editTextHand=view.findViewById(R.id.editText_handNumber);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        practiceAction=new PracticeAction(this.getContext());
        spinnerGrade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                PracticeAction practiceAction=new PracticeAction(getContext());
                ArrayAdapter<String> adapterOral=null;
                ArrayAdapter<String> adapterHand=null;
                switch (spinnerGrade.getSelectedItem().toString()){
                    case "一年级":
                        practiceAction.updateGrade(1);
                        adapterOral=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.ORAL_GRADE_1);
                        adapterHand=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.HAND_GRADE_1);
                        break;
                    case "二年级":
                        practiceAction.updateGrade(2);
                        adapterOral=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.ORAL_GRADE_2);
                        adapterHand=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.HAND_GRADE_2);
                        break;
                    case "三年级":
                        practiceAction.updateGrade(3);
                        adapterOral=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.ORAL_GRADE_3);
                        adapterHand=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.HAND_GRADE_3);
                        break;
                    case "四年级":
                        practiceAction.updateGrade(4);
                        adapterOral=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.ORAL_GRADE_4);
                        adapterHand=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.HAND_GRADE_4);
                        break;
                    case "五年级":
                        practiceAction.updateGrade(5);
                        adapterOral=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.ORAL_GRADE_5);
                        adapterHand=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.HAND_GRADE_5);
                        break;
                    case "六年级":
                        practiceAction.updateGrade(6);
                        adapterOral=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.ORAL_GRADE_6);
                        adapterHand=new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, Types.HAND_GRADE_6);
                        break;
                    default:
                }
                spinnerOral.setAdapter(adapterOral);
                spinnerHand.setAdapter(adapterHand);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinnerOral.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(spinnerOral.getContext(),spinnerOral.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
                oralType=spinnerOral.getSelectedItem().toString();
                switch(spinnerOral.getSelectedItem().toString()){
                    case "5以内加法":
                        argumentOral= Arguments.ARG_ORAL_1_1;
                        break;
                    case "5以内减法":
                        argumentOral= Arguments.ARG_ORAL_1_2;
                        break;
                    case "10以内加减法":
                        argumentOral= Arguments.ARG_ORAL_1_3;
                        break;
                    case "10以内连加、连减":
                        argumentOral= Arguments.ARG_ORAL_1_4;
                        break;
                    case "10以内加减混合":
                        argumentOral= Arguments.ARG_ORAL_1_5;
                        break;
                    case "20以内加减混合":
                        argumentOral= Arguments.ARG_ORAL_1_6;
                        break;
                    case "100以内的加减混合":
                        argumentOral= Arguments.ARG_ORAL_1_7;
                        break;
                    case "100以内的减法":
                        argumentOral= Arguments.ARG_ORAL_1_8;
                        break;
                    case "100以内的加法":
                        argumentOral= Arguments.ARG_ORAL_1_9;
                        break;


                    case "加法，减法，混合加减":
                        argumentOral=Arguments.ARG_ORAL_2_1;
                        break;
                    case "9x9乘法":
                        argumentOral=Arguments.ARG_ORAL_2_2;
                        break;
                    case "10以内乘加，乘减":
                        argumentOral=Arguments.ARG_ORAL_2_3;
                        break;
                    case "100以内除以个位数。得数需为整数":
                        argumentOral=Arguments.ARG_ORAL_2_4;
                        break;
                    case "除加，除减":
                        argumentOral=Arguments.ARG_ORAL_2_5;
                        break;
                    case "100-1000的加减法":
                        argumentOral=Arguments.ARG_ORAL_2_6;
                        break;

                    case "一位数除两位数，结果为整数":
                        argumentOral=Arguments.ARG_ORAL_3_1;
                        break;
                    case "一位数除三位数，结果为整数":
                        argumentOral=Arguments.ARG_ORAL_3_2;
                        break;
                    case "两位数乘一位数":
                        argumentOral=Arguments.ARG_ORAL_3_3;
                        break;
                    case "两位数相乘":
                        argumentOral=Arguments.ARG_ORAL_3_4;
                        break;
                    case "含小数的加减法":
                        argumentOral=Arguments.ARG_ORAL_3_5;
                        break;

                    case "含括号的三运算符":
                        argumentOral=Arguments.ARG_ORAL_4_1;
                        break;
                    case "含小数的加，减法":
                        argumentOral=Arguments.ARG_ORAL_4_2;
                        break;

                    case "除数是整数,算式可除的小数除法":
                        argumentOral=Arguments.ARG_ORAL_5_1;
                        break;
                    case "小数乘，除法":
                        argumentOral=Arguments.ARG_ORAL_5_2;
                        break;
                    case "同分母的分数加，减法":
                        argumentOral=Arguments.ARG_ORAL_5_3;
                        break;
                    case "异分母的加，减法":
                        argumentOral=Arguments.ARG_ORAL_5_4;
                        break;
                    case "含分母的加减混合运算":
                        argumentOral=Arguments.ARG_ORAL_5_5;
                        break;

                    case "分数乘整数":
                        argumentOral=Arguments.ARG_ORAL_6_1;
                        break;
                    case "分数乘分数":
                        argumentOral=Arguments.ARG_ORAL_6_2;
                        break;

                    default:
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinnerHand.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                handType=spinnerHand.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        buttonOralStart.setOnClickListener((View v)->{
            if(editTextOral.getText().length()>0){
                String input=editTextOral.getText().toString();
                if(input.length()<=3){


                int amount=Integer.parseInt(input);
                if(amount<=100&&amount>0){
                    argumentOral.setAmount(amount);
                    practiceAction.startGenerating(argumentOral);
                    PracticePageFragment.initialData();
                    Intent intent=new Intent(this.getContext(),PracticeActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(this.getContext(),"题目数量不合法",Toast.LENGTH_SHORT).show();
                }
                }else{
                    Toast.makeText(this.getContext(),"题目数量不合法",Toast.LENGTH_SHORT).show();
                }
            }


        });

        buttonHandStart.setOnClickListener((View v)->{
            Intent intent=new Intent(this.getContext(),PracticeActivity.class);
            startActivity(intent);
        });

        buttonOralPrint.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(this.getContext());

            if(editTextOral.getText().length()>0){
                String input=editTextOral.getText().toString();
                if(input.length()<=3){


                    int amount=Integer.parseInt(input);
                if(amount<=100&&amount>0){
                    argumentOral.setAmount(amount);
                    practiceAction.startPrinter(argumentOral);
                }else{
                    Toast.makeText(this.getContext(),"题目数量不合法",Toast.LENGTH_SHORT).show();
                }
                }else{
                    Toast.makeText(this.getContext(),"题目数量不合法",Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonHandPrint.setOnClickListener((View v)->{
            PracticeAction practiceAction=new PracticeAction(this.getContext());

            if(editTextHand.getText().length()>0){
                int amount=Integer.parseInt(editTextHand.getText().toString());
                if(amount<=100&&amount>0){
                    argumentHand.setAmount(amount);
                    practiceAction.startPrinter(argumentHand);
                }else{
                    Toast.makeText(this.getContext(),"题目数量不合法",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}